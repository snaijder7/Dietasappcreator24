App: Dietas 2.6 Tsj
Versión demo local / instalable como PWA

1️⃣ Abrir index.html para probar localmente.
2️⃣ Para usar como App en Android, sube esta carpeta a:
   👉 https://www.pwabuilder.com
   o https://appcreator24.com (cuando el servicio vuelva).
3️⃣ El master puede configurar precios, usuarios y contraseñas.
4️⃣ El login se guarda en el dispositivo (localStorage).
